import { html, render } from "../node_modules/lit-html/lit-html.js";
import page from "../node_modules/page/page.mjs"
import { updateFunc } from "../app.js"

let loginTemplate = () => html`
<section id="loginPage">
    <form @submit=${onSubmit} class="loginForm">
        <img src="./images/logo.png" alt="logo" />
        <h2>Login</h2>

        <div>
            <label for="email">Email:</label>
            <input id="email" name="email" type="text" placeholder="steven@abv.bg" value="">
        </div>

        <div>
            <label for="password">Password:</label>
            <input id="password" name="password" type="password" placeholder="********" value="">
        </div>

        <button class="btn" type="submit">Login</button>

        <p class="field">
            <span>If you don't have profile click <a href="#">here</a></span>
        </p>
    </form>
</section>
`

function onSubmit(e) {
    e.preventDefault()
    let formData = new FormData(e.currentTarget)
    let email = formData.get("email")
    let password = formData.get("password")

    if (email.length == 0 || password.length == 0) {
        return;
    }
    fetch("http://localhost:3030/users/login", {
        method: "POST",
        body: JSON.stringify({ email, password })
    })
        .then(res => {
            if (!res.ok) {
                throw new Error("Wrong credentials")
            }
            return res.json()
        })
        .then(data => {
            localStorage.setItem("ownerId", data._id)
            localStorage.setItem("token", data.accessToken)
            updateFunc()
            page.redirect("/home")
        })
        .catch(error => alert(error.message))
}

export const loginVie = (ctx) => render(loginTemplate(), document.getElementById("content"))

