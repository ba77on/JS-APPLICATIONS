import { html, render } from "../node_modules/lit-html/lit-html.js";
import page from "../node_modules/page/page.mjs"

const catalogTemplateView = (catalog) => html`
<section id="dashboard">
    <h2 class="dashboard-title">Services for every animal</h2>
    <div class="animals-dashboard">
        ${catalog.length == 0 ? html` <div>
            <p class="no-pets">No pets in dashboard</p>
        </div>` : catalog.map(singlePetTemplate)}

    </div>
</section>
    `

const singlePetTemplate = (singlePet) => html`
            <div class="animals-board">
                <article class="service-img">
                    <img class="animal-image-cover" src="${singlePet.image}">
                </article>
                <h2 class="name">${singlePet.name}</h2>
                <h3 class="breed">${singlePet.breed}</h3>
                <div class="action">
                    <a class="btn" href="/details/${singlePet._id}">Details</a>
                </div>
            </div>
    `

let dataGetFunc = () => fetch("http://localhost:3030/data/pets?sortBy=_createdOn%20desc&distinct=name")
    .then(res => {
        if (!res.ok) {
            throw new Error("bad url")
        }
        return res.json()
    })
    .then(data => Object.values(data))
    .catch(error => alert(error.message))

export const catalogView = (ctx) => dataGetFunc()
    .then(catalog => render(catalogTemplateView(catalog), document.getElementById("content")))