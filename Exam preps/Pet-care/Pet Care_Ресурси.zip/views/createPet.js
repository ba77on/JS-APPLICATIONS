import { html, render } from "../node_modules/lit-html/lit-html.js";
import page from "../node_modules/page/page.mjs"

const createPetTemplate = () => html`
<section id="createPage">
    <form @submit=${onSubmit} class="createForm">
        <img src="./images/cat-create.jpg">
        <div>
            <h2>Create PetPal</h2>
            <div class="name">
                <label for="name">Name:</label>
                <input name="name" id="name" type="text" placeholder="Max">
            </div>
            <div class="breed">
                <label for="breed">Breed:</label>
                <input name="breed" id="breed" type="text" placeholder="Shiba Inu">
            </div>
            <div class="Age">
                <label for="age">Age:</label>
                <input name="age" id="age" type="text" placeholder="2 years">
            </div>
            <div class="weight">
                <label for="weight">Weight:</label>
                <input name="weight" id="weight" type="text" placeholder="5kg">
            </div>
            <div class="image">
                <label for="image">Image:</label>
                <input name="image" id="image" type="text" placeholder="./image/dog.jpeg">
            </div>
            <button class="btn" type="submit">Create Pet</button>
        </div>
    </form>
</section>
`

function onSubmit(e) {
    e.preventDefault()
    let formData = new FormData(e.currentTarget)
    let name = formData.get("name")
    let breed = formData.get("breed")
    let age = formData.get("age")
    let weight = formData.get("weight")
    let image = formData.get("image")


    let petName = document.getElementById("name")
    let petBreed = document.getElementById("breed")
    let petAge = document.getElementById("age")
    let petWeight = document.getElementById("weight")
    let img = document.getElementById("image")

    if (petName.value.length == 0 || petBreed.value.length == 0 || petAge.value.length == 0 || petWeight.value.length == 0 || img.value.length == 0) {
        return;
    }

    fetch("http://localhost:3030/data/pets", {
        method: "POST",
        headers: {
            "X-Authorization": localStorage.token
        },
        body: JSON.stringify({ name, breed, age, weight, image })
    }).then(res => {
        if (!res.ok) {
            throw new Error("Didnt create a Post")
        }
        return res.json()
    })
        .then(data => {
            page.redirect("/home")
        })
        .catch(err => alert(error.message))

}

export const createView = () => render(createPetTemplate(), document.getElementById("content"))