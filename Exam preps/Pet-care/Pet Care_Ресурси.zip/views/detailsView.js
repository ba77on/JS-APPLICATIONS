import { html, render } from "../node_modules/lit-html/lit-html.js";
import page from "../node_modules/page/page.mjs"

const detailsTemplate = (pet, onDelete) => html`
<section id="detailsPage">
    <div class="details">
        <div class="animalPic">
            <img src="${pet.image}">
        </div>
        <div>
            <div class="animalInfo">
                <h1>Name: ${pet.name}</h1>
                <h3>Breed: ${pet.breed}</h3>
                <h4>Age: ${pet.age}</h4>
                <h4>Weight: ${pet.weight}</h4>
            </div>
            <!-- if there is no registered user, do not display div-->
            <div class="actionBtn">
                <!-- Only for registered user and creator of the pets-->
                <a href="/details/${pet._id}/edit" class="edit" style="display: ${pet._ownerId == localStorage.ownerId ? "inline": "none"}":>Edit</a>
                <a href="#"@click =${onDelete} class="remove" style="display: ${pet._ownerId == localStorage.ownerId ? "inline": "none"}">Delete</a>
            </div>
        </div>
    </div>
</section>
`

let post = '';

const getData = (detailsId) => {
    return fetch(`http://localhost:3030/data/pets/${detailsId}`)
        .then(res => res.json())
}


export const detailsView = (ctx) => {
    getData(ctx.params.detailsId)
        .then(singlePet => render(detailsTemplate(singlePet), document.getElementById("content")))
        post = ctx.params.detailsId
}

async function onDelete(post) {
    const choice = confirm = ("are you sure you want to delete?")
    if(choice) {
        fetch(`http://localhost:3030//data/pets/${post}`,{
            method: "Delete",
            headers: {
                
            }
        })
        page.redirect("/")
    }
}



// async function onDelete(){
//     const choice = confirm('Are you sure, you want to delete this meme?')
    
//     if(choice){
//         await deletePetById(ctx.params.id)
//         ctx.page.redirect('/')
//     }
    
//     }
    
//     }